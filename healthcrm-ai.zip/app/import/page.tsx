"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, Button } from "@/components/ui";
import { UploadCloud, FileText, CheckCircle2, AlertCircle } from "lucide-react";
import Papa from "papaparse";

export default function ImportPage() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<{totalImported: number, totalSkipped: number} | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    setFile(selectedFile);

    Papa.parse(selectedFile, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setParsedData(results.data);
      },
    });
  };

  const handleConfirmImport = async () => {
    setIsProcessing(true);
    try {
      // In a real app, this would send batches to the backend.
      // Here we simulate the batch processing and AI mapping with a single API call for simplicity.
      const res = await fetch("/api/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records: parsedData }),
      });
      const data = await res.json();
      setResults(data);
    } catch (error) {
      console.error(error);
      alert("Import failed.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Import Data</h1>
          <p className="text-gray-500 mt-2">Upload a CSV file to bulk import CRM leads and interactions.</p>
        </div>
      </div>

      {!results ? (
        <Card>
          <CardHeader>
            <CardTitle>Upload CSV File</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {!file ? (
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:bg-gray-50 transition-colors">
                <UploadCloud className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">Click to upload or drag and drop</h3>
                <p className="text-sm text-gray-500 mb-6">CSV files only</p>
                <input
                  type="file"
                  accept=".csv"
                  className="hidden"
                  id="csv-upload"
                  onChange={handleFileUpload}
                />
                <Button onClick={() => document.getElementById('csv-upload')?.click()}>
                  Select File
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center gap-4 p-4 bg-blue-50 border border-blue-100 rounded-lg">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{file.name}</h4>
                    <p className="text-sm text-gray-500">{parsedData.length} records found</p>
                  </div>
                  <Button variant="outline" onClick={() => { setFile(null); setParsedData([]); }}>
                    Change File
                  </Button>
                </div>

                {parsedData.length > 0 && (
                  <div className="border rounded-lg overflow-x-auto max-h-[400px]">
                    <table className="w-full text-sm text-left">
                      <thead className="text-xs text-gray-700 bg-gray-50 sticky top-0 shadow-sm">
                        <tr>
                          {Object.keys(parsedData[0]).map((key) => (
                            <th key={key} className="px-6 py-3 whitespace-nowrap">{key}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {parsedData.slice(0, 10).map((row, i) => (
                          <tr key={i} className="bg-white border-b hover:bg-gray-50">
                            {Object.values(row as Record<string, string>).map((val, j) => (
                              <td key={j} className="px-6 py-4 whitespace-nowrap">{val}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {parsedData.length > 10 && (
                      <div className="p-3 text-center text-xs text-gray-500 bg-gray-50 border-t">
                        Showing 10 of {parsedData.length} rows
                      </div>
                    )}
                  </div>
                )}

                <div className="flex justify-end pt-4">
                  <Button onClick={handleConfirmImport} disabled={isProcessing || parsedData.length === 0} className="w-full sm:w-auto">
                    {isProcessing ? "Processing via AI..." : "Confirm Import & Process"}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card className="border-green-200 bg-green-50 text-green-900">
          <CardContent className="pt-6 flex flex-col items-center text-center space-y-4">
            <CheckCircle2 className="w-16 h-16 text-green-500" />
            <h2 className="text-2xl font-bold">Import Complete</h2>
            <div className="flex gap-8 mt-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-green-700">{results.totalImported}</p>
                <p className="text-sm font-medium opacity-80 mt-1">Successfully Imported</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-gray-500">{results.totalSkipped}</p>
                <p className="text-sm font-medium opacity-80 mt-1">Skipped (Missing required fields)</p>
              </div>
            </div>
            <div className="pt-6">
              <Button onClick={() => router.push('/history')} variant="outline" className="bg-white hover:bg-green-100 border-green-300 text-green-800">
                View in History
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
