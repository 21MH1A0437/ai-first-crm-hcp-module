"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, Button, Input, Textarea, Label } from "@/components/ui";
import { Sparkles, Save, FileText, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function LogInteractionPage() {
  const router = useRouter();
  const [tab, setTab] = useState<'ai'|'manual'>('ai');
  const [prompt, setPrompt] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [formData, setFormData] = useState({
    doctorName: "",
    hospital: "",
    meetingDate: new Date().toISOString().split('T')[0],
    productsDiscussed: "",
    discussionSummary: "",
    sentiment: "neutral",
    followUpDate: "",
    actionItems: ""
  });

  const [reviewMode, setReviewMode] = useState(false);

  const handleAiExtract = async () => {
    if (!prompt.trim()) return;
    setIsProcessing(true);
    try {
      const res = await fetch("/api/extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      
      setFormData(prev => ({
        ...prev,
        doctorName: data.doctorName || prev.doctorName,
        hospital: data.hospital || prev.hospital,
        meetingDate: data.meetingDate || prev.meetingDate,
        productsDiscussed: data.productsDiscussed ? data.productsDiscussed.join(", ") : prev.productsDiscussed,
        discussionSummary: data.discussionSummary || prev.discussionSummary,
        sentiment: data.sentiment || prev.sentiment,
        followUpDate: data.followUpDate || prev.followUpDate,
        actionItems: data.actionItems ? data.actionItems.join(", ") : prev.actionItems,
      }));
      
      setTab('manual'); // switch to manual to review
      setReviewMode(true);
    } catch (error) {
      console.error(error);
      alert("Failed to extract data using AI.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSave = async () => {
    try {
      setIsProcessing(true);
      const payload = {
        ...formData,
        productsDiscussed: formData.productsDiscussed.split(",").map(s => s.trim()).filter(Boolean),
        actionItems: formData.actionItems.split(",").map(s => s.trim()).filter(Boolean),
      };
      
      const res = await fetch("/api/interactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      
      if (res.ok) {
        router.push("/history");
      } else {
        alert("Failed to save interaction.");
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Log Interaction</h1>
          <p className="text-gray-500 mt-2">Record your meeting with an HCP.</p>
        </div>
      </div>

      <div className="flex gap-4 border-b border-gray-200">
        <button
          className={`pb-3 px-1 border-b-2 font-medium text-sm transition-colors ${tab === 'ai' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-900'}`}
          onClick={() => setTab('ai')}
        >
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            AI Assist
          </div>
        </button>
        <button
          className={`pb-3 px-1 border-b-2 font-medium text-sm transition-colors ${tab === 'manual' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-900'}`}
          onClick={() => setTab('manual')}
        >
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            {reviewMode ? 'Review & Edit' : 'Manual Entry'}
          </div>
        </button>
      </div>

      <AnimatePresence mode="wait">
        {tab === 'ai' && (
          <motion.div key="ai" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
            <Card>
              <CardHeader>
                <CardTitle>AI Natural Language Logging</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Type or dictate your meeting notes naturally. Our AI will automatically extract the doctor&apos;s name, hospital, discussed products, and action items.
                </p>
                <Textarea
                  placeholder="e.g. Today I met Dr. Smith at Apollo Hospital. We discussed our new diabetes medicine. He was interested in the clinical results and requested pricing information. I need to follow up next Friday."
                  className="min-h-[150px] resize-y text-base p-4"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
                <Button onClick={handleAiExtract} disabled={isProcessing || !prompt.trim()} className="w-full sm:w-auto">
                  {isProcessing ? "Extracting..." : "Process with AI"}
                  <Sparkles className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {tab === 'manual' && (
          <motion.div key="manual" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
            {reviewMode && (
              <div className="mb-6 p-4 bg-green-50 text-green-800 rounded-lg flex items-start gap-3 border border-green-200">
                <CheckCircle2 className="w-5 h-5 mt-0.5 text-green-600" />
                <div>
                  <h4 className="font-semibold">AI Extraction Complete</h4>
                  <p className="text-sm mt-1">Review the extracted information below and make any necessary corrections before saving.</p>
                </div>
              </div>
            )}
            
            <Card>
              <CardHeader>
                <CardTitle>Interaction Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="doctorName">Doctor Name *</Label>
                    <Input id="doctorName" value={formData.doctorName} onChange={(e) => setFormData({...formData, doctorName: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hospital">Hospital / Clinic *</Label>
                    <Input id="hospital" value={formData.hospital} onChange={(e) => setFormData({...formData, hospital: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="meetingDate">Meeting Date *</Label>
                    <Input id="meetingDate" type="date" value={formData.meetingDate} onChange={(e) => setFormData({...formData, meetingDate: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sentiment">Sentiment</Label>
                    <select
                      id="sentiment"
                      className="flex h-9 w-full rounded-md border border-gray-200 bg-transparent px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-blue-600"
                      value={formData.sentiment}
                      onChange={(e) => setFormData({...formData, sentiment: e.target.value})}
                    >
                      <option value="positive">Positive</option>
                      <option value="neutral">Neutral</option>
                      <option value="negative">Negative</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="productsDiscussed">Products Discussed (comma separated)</Label>
                  <Input id="productsDiscussed" placeholder="e.g. Medicine A, Product B" value={formData.productsDiscussed} onChange={(e) => setFormData({...formData, productsDiscussed: e.target.value})} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="discussionSummary">Discussion Summary *</Label>
                  <Textarea id="discussionSummary" className="min-h-[100px]" value={formData.discussionSummary} onChange={(e) => setFormData({...formData, discussionSummary: e.target.value})} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="actionItems">Action Items / Notes (comma separated)</Label>
                  <Input id="actionItems" placeholder="e.g. Send pricing, Schedule follow-up" value={formData.actionItems} onChange={(e) => setFormData({...formData, actionItems: e.target.value})} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="followUpDate">Follow-up Date</Label>
                  <Input id="followUpDate" type="date" value={formData.followUpDate} onChange={(e) => setFormData({...formData, followUpDate: e.target.value})} />
                </div>

                <div className="pt-4 flex justify-end gap-3">
                  <Button variant="outline" onClick={() => router.push('/')}>Cancel</Button>
                  <Button onClick={handleSave} disabled={isProcessing || !formData.doctorName || !formData.hospital || !formData.discussionSummary}>
                    <Save className="w-4 h-4 mr-2" />
                    {isProcessing ? "Saving..." : "Save Interaction"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
