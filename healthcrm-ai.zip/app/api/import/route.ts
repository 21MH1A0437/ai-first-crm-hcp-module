import { NextRequest, NextResponse } from "next/server";
import { saveInteraction } from "@/lib/db";
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { records } = await req.json();
    
    let totalImported = 0;
    let totalSkipped = 0;

    // For demonstration, we'll only process the first 10 records using AI
    // to avoid hitting rate limits or timeouts during the preview.
    const batch = records.slice(0, 10);
    const remaining = records.length - 10;
    
    // We send the batch to AI to map the schema
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `You are an AI CRM data extractor. Map the following CSV records into CRM JSON format. 
      Skip records without email or contact info if it feels like invalid data, but for our prototype, just map what you can into doctorName, hospital, discussionSummary, etc.
      
      CSV Records (JSON):
      ${JSON.stringify(batch)}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              doctorName: { type: Type.STRING },
              hospital: { type: Type.STRING },
              discussionSummary: { type: Type.STRING },
              sentiment: { type: Type.STRING },
              meetingDate: { type: Type.STRING },
            },
            required: ["doctorName"]
          }
        }
      }
    });

    const text = response.text;
    if (text) {
      const mappedData = JSON.parse(text);
      for (const item of mappedData) {
        if (item.doctorName) {
          saveInteraction({
            doctorName: item.doctorName,
            hospital: item.hospital || 'Unknown',
            meetingDate: item.meetingDate || new Date().toISOString().split('T')[0],
            productsDiscussed: [],
            discussionSummary: item.discussionSummary || 'Imported via CSV',
            keyQuestions: [],
            sentiment: item.sentiment || 'neutral',
            followUpDate: '',
            actionItems: []
          });
          totalImported++;
        } else {
          totalSkipped++;
        }
      }
    }
    
    // Assume the rest are skipped or processed similarly.
    if (remaining > 0) {
      totalSkipped += remaining;
    }

    return NextResponse.json({ totalImported, totalSkipped });
  } catch (error: any) {
    console.error("Error in Import:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
