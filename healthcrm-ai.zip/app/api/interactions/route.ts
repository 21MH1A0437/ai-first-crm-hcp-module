import { NextRequest, NextResponse } from "next/server";
import { getInteractions, saveInteraction } from "@/lib/db";

export async function GET() {
  try {
    const interactions = getInteractions();
    return NextResponse.json(interactions);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const data = await req.json();
    const newInteraction = saveInteraction({
      doctorName: data.doctorName || '',
      hospital: data.hospital || '',
      meetingDate: data.meetingDate || '',
      productsDiscussed: data.productsDiscussed || [],
      discussionSummary: data.discussionSummary || '',
      keyQuestions: data.keyQuestions || [],
      sentiment: data.sentiment || 'neutral',
      followUpDate: data.followUpDate || '',
      actionItems: data.actionItems || [],
    });
    return NextResponse.json(newInteraction, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
