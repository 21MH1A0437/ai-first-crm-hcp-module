import { GoogleGenAI, Type } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { prompt } = await req.json();

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Extract CRM interaction details from the following conversation/notes.
      
      Conversation/Notes:
      ${prompt}`,
      config: {
        systemInstruction: "You are an AI assistant that extracts structured CRM data for Healthcare Professional (HCP) interactions from natural language text. If some information is not present, leave it empty or omit it. For sentiment, classify as positive, neutral, or negative.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            doctorName: { type: Type.STRING, description: "Name of the doctor/HCP" },
            hospital: { type: Type.STRING, description: "Hospital or clinic name" },
            meetingDate: { type: Type.STRING, description: "Date of the meeting (YYYY-MM-DD)" },
            productsDiscussed: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of products or medicines discussed" },
            discussionSummary: { type: Type.STRING, description: "A concise summary of the discussion" },
            keyQuestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Key questions asked by the HCP" },
            sentiment: { type: Type.STRING, description: "positive, neutral, or negative" },
            followUpDate: { type: Type.STRING, description: "Suggested follow-up date (YYYY-MM-DD)" },
            actionItems: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Action items or next steps" }
          },
          required: ["doctorName", "discussionSummary"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No text returned from Gemini.");
    }
    const data = JSON.parse(text);
    return NextResponse.json(data);
  } catch (error: any) {
    console.error("Error in AI extraction:", error);
    return NextResponse.json({ error: error.message || "Failed to extract data" }, { status: 500 });
  }
}
