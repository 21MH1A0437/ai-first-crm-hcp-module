"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, Input, Button } from "@/components/ui";
import { Search, Calendar, MapPin, Stethoscope, ChevronRight } from "lucide-react";
import Link from "next/link";
import { Interaction } from "@/lib/db";

export default function HistoryPage() {
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/api/interactions")
      .then(res => res.json())
      .then(data => {
        setInteractions(data);
        setLoading(false);
      })
      .catch(console.error);
  }, []);

  const filtered = interactions.filter(i => 
    i.doctorName.toLowerCase().includes(search.toLowerCase()) || 
    i.hospital.toLowerCase().includes(search.toLowerCase()) ||
    i.discussionSummary.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Interaction History</h1>
          <p className="text-gray-500 mt-2">View and manage your past HCP meetings.</p>
        </div>
        <Link href="/log">
          <Button>Log New Interaction</Button>
        </Link>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Search by doctor name, hospital, or keywords..."
              className="pl-10 text-base"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {loading ? (
        <div className="text-center text-gray-500 py-12">Loading history...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center text-gray-500 py-12 bg-white rounded-xl border border-dashed border-gray-300">
          <p>No interactions found.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(interaction => (
            <Card key={interaction.id} className="hover:shadow-md transition-shadow cursor-pointer group">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="space-y-3 flex-1">
                    <div className="flex items-center gap-3">
                      <h3 className="text-lg font-semibold text-gray-900">{interaction.doctorName}</h3>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        interaction.sentiment === 'positive' ? 'bg-green-100 text-green-700' :
                        interaction.sentiment === 'negative' ? 'bg-red-100 text-red-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {interaction.sentiment.charAt(0).toUpperCase() + interaction.sentiment.slice(1)}
                      </span>
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        {interaction.hospital}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        {interaction.meetingDate}
                      </div>
                      {interaction.productsDiscussed && interaction.productsDiscussed.length > 0 && (
                        <div className="flex items-center gap-1.5">
                          <Stethoscope className="w-4 h-4 text-gray-400" />
                          {interaction.productsDiscussed.join(", ")}
                        </div>
                      )}
                    </div>

                    <p className="text-gray-700 line-clamp-2 mt-2 text-sm">
                      {interaction.discussionSummary}
                    </p>
                    
                    {interaction.actionItems && interaction.actionItems.length > 0 && (
                       <div className="text-sm font-medium text-blue-600 mt-2">
                         Next Steps: {interaction.actionItems.join(", ")}
                       </div>
                    )}
                  </div>
                  
                  <div className="pl-4 pt-2">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
