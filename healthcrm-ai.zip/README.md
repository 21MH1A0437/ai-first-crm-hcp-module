# HealthCRM AI - AI-First CRM HCP Module

An intelligent Customer Relationship Management (CRM) application designed specifically for pharmaceutical and life science field representatives. It simplifies logging interactions with Healthcare Professionals (HCPs) using natural language and AI data extraction.

## Features

- **AI-Powered Interaction Logging**: Log meetings using natural language. The system extracts doctor names, hospitals, topics, sentiments, and follow-up actions automatically using the Gemini AI API.
- **Manual Form Entry**: Traditional structured form for direct data entry.
- **Interaction History**: View, search, and manage past interactions.
- **CSV Data Import**: Bulk import leads and interactions via CSV with AI-assisted schema mapping.

## Technology Stack

- **Frontend**: Next.js 15 (App Router), React, Tailwind CSS, Framer Motion, Lucide Icons.
- **Backend**: Next.js API Routes (Node.js).
- **AI Processing**: Google Gemini API (@google/genai).
- **Storage**: Local JSON persistence (for prototype).

## Folder Structure

```
├── app/
│   ├── api/
│   │   ├── extract/route.ts      # AI extraction endpoint
│   │   ├── import/route.ts       # CSV batch import & mapping endpoint
│   │   └── interactions/route.ts # CRUD for interactions
│   ├── history/page.tsx          # History view
│   ├── import/page.tsx           # CSV drag & drop import view
│   ├── log/page.tsx              # AI/Manual logging view
│   ├── layout.tsx                # Main app layout with Sidebar
│   └── page.tsx                  # Dashboard Home
├── components/
│   ├── Sidebar.tsx               # App navigation sidebar
│   └── ui/                       # Reusable Tailwind UI components
├── lib/
│   ├── db.ts                     # Local JSON database utility
│   └── utils.ts                  # Helper functions (e.g., Tailwind merge)
├── public/                       # Static assets
└── package.json                  # App dependencies
```

## Environment Variables

Create a `.env` file in the root directory:

```env
# Required for AI natural language processing and data extraction
GEMINI_API_KEY="your_gemini_api_key_here"
```

## Installation & Running Locally

1. **Clone the repository**
2. **Install dependencies:**
   ```bash
   npm install
   ```
3. **Start the development server:**
   ```bash
   npm run dev
   ```
4. Open `http://localhost:3000` in your browser.

## API Documentation

### `POST /api/extract`
Extracts structured CRM data from natural language text.
- **Body:** `{ "prompt": "Meeting notes text..." }`
- **Response:** JSON object matching the Interaction schema.

### `GET /api/interactions`
Retrieves all saved interactions.

### `POST /api/interactions`
Saves a new interaction record.
- **Body:** Interaction object.

### `POST /api/import`
Processes and maps CSV records into the CRM schema using AI.
- **Body:** `{ "records": [...] }`
- **Response:** `{ "totalImported": 10, "totalSkipped": 2 }`
