import fs from 'fs';
import path from 'path';

const dataFile = path.join(process.cwd(), 'data.json');

export interface Interaction {
  id: string;
  doctorName: string;
  hospital: string;
  meetingDate: string;
  productsDiscussed: string[];
  discussionSummary: string;
  keyQuestions: string[];
  sentiment: string;
  followUpDate: string;
  actionItems: string[];
  createdAt: string;
}

export function getInteractions(): Interaction[] {
  if (!fs.existsSync(dataFile)) {
    return [];
  }
  const data = fs.readFileSync(dataFile, 'utf-8');
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function saveInteraction(interaction: Omit<Interaction, 'id' | 'createdAt'>): Interaction {
  const interactions = getInteractions();
  const newInteraction = {
    ...interaction,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  };
  interactions.unshift(newInteraction);
  fs.writeFileSync(dataFile, JSON.stringify(interactions, null, 2));
  return newInteraction;
}

export function updateInteraction(id: string, updates: Partial<Interaction>): Interaction | null {
  const interactions = getInteractions();
  const index = interactions.findIndex(i => i.id === id);
  if (index === -1) return null;
  
  const updated = { ...interactions[index], ...updates };
  interactions[index] = updated;
  fs.writeFileSync(dataFile, JSON.stringify(interactions, null, 2));
  return updated;
}
